import { Button } from "@/components/ui/button";
import { Scan, Users, Clock, Shield } from "lucide-react";
import heroImage from "@/assets/hero-medical.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Modern hospital lobby" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-medical-green/80"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center text-white">
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <Shield className="w-4 h-4" />
              <span className="text-sm font-medium">Secure Face Recognition</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Smart Queue
              <span className="block bg-gradient-to-r from-yellow-300 to-green-300 bg-clip-text text-transparent">
                Hospital Management
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed">
              Revolutionary healthcare queue system powered by facial recognition technology. 
              No more waiting cards, no more confusion. Just seamless patient experience.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button variant="scan" size="xl" className="gap-3">
              <Scan className="w-5 h-5" />
              Patient Login
            </Button>
            <Button variant="outline" size="xl" className="gap-3 bg-white/10 border-white/30 text-white hover:bg-white/20">
              <Users className="w-5 h-5" />
              Admin Dashboard
            </Button>
          </div>
          
          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Scan className="w-8 h-8 mb-4 mx-auto text-yellow-300" />
              <h3 className="text-lg font-semibold mb-2">Face Recognition</h3>
              <p className="text-white/80 text-sm">
                Secure patient identification using advanced facial recognition technology
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Clock className="w-8 h-8 mb-4 mx-auto text-green-300" />
              <h3 className="text-lg font-semibold mb-2">Real-time Queue</h3>
              <p className="text-white/80 text-sm">
                Live queue updates and estimated waiting times for all patients
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Users className="w-8 h-8 mb-4 mx-auto text-blue-300" />
              <h3 className="text-lg font-semibold mb-2">Smart Management</h3>
              <p className="text-white/80 text-sm">
                Efficient queue management system for healthcare professionals
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;