import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Send, MessageCircle, Users, Clock, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  patientId: string;
  patientName: string;
  message: string;
  timestamp: Date;
  type: 'patient' | 'system';
}

interface Patient {
  id: string;
  name: string;
  queuePosition: number;
  isOnline: boolean;
  initials: string;
}

const LiveChatBox = ({ currentPatient }: { currentPatient: any }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [onlinePatients, setOnlinePatients] = useState<Patient[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Mock data for patients in the same queue
  useEffect(() => {
    const mockPatients: Patient[] = [
      { id: "P002", name: "Sarah Johnson", queuePosition: 1, isOnline: true, initials: "SJ" },
      { id: "P003", name: "Mike Wilson", queuePosition: 2, isOnline: true, initials: "MW" },
      { id: "P001", name: "John Doe", queuePosition: 3, isOnline: true, initials: "JD" },
      { id: "P004", name: "Emma Davis", queuePosition: 4, isOnline: false, initials: "ED" },
      { id: "P005", name: "Robert Chen", queuePosition: 5, isOnline: true, initials: "RC" }
    ];
    setOnlinePatients(mockPatients);

    // Mock initial messages
    const initialMessages: ChatMessage[] = [
      {
        id: "1",
        patientId: "P002",
        patientName: "Sarah Johnson",
        message: "Hi everyone! How long have you been waiting?",
        timestamp: new Date(Date.now() - 300000),
        type: 'patient'
      },
      {
        id: "2",
        patientId: "P003",
        patientName: "Mike Wilson",
        message: "About 20 minutes. Dr. Smith is really thorough though, worth the wait!",
        timestamp: new Date(Date.now() - 240000),
        type: 'patient'
      },
      {
        id: "3",
        patientId: "system",
        patientName: "System",
        message: "John Doe joined the chat",
        timestamp: new Date(Date.now() - 180000),
        type: 'system'
      }
    ];
    setMessages(initialMessages);
  }, []);

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    const message: ChatMessage = {
      id: Date.now().toString(),
      patientId: currentPatient?.id || "P001",
      patientName: currentPatient?.name || "John Doe",
      message: newMessage.trim(),
      timestamp: new Date(),
      type: 'patient'
    };

    setMessages(prev => [...prev, message]);
    setNewMessage("");

    // Simulate response from another patient
    setTimeout(() => {
      const responses = [
        "That's helpful, thank you!",
        "I had a similar experience with Dr. Smith.",
        "Thanks for sharing that information.",
        "Hope your appointment goes well!",
        "Good to know, appreciate it!"
      ];
      
      const randomPatient = onlinePatients.find(p => p.id !== currentPatient?.id && p.isOnline);
      if (randomPatient) {
        const response: ChatMessage = {
          id: (Date.now() + 1).toString(),
          patientId: randomPatient.id,
          patientName: randomPatient.name,
          message: responses[Math.floor(Math.random() * responses.length)],
          timestamp: new Date(),
          type: 'patient'
        };
        setMessages(prev => [...prev, response]);
      }
    }, 2000 + Math.random() * 3000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const openChat = () => {
    setIsOpen(true);
    toast({
      title: "Chat Opened",
      description: "You can now chat with other patients in your queue.",
    });
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={openChat}
          variant="medical"
          size="lg"
          className="gap-2 shadow-medical rounded-full"
        >
          <MessageCircle className="w-5 h-5" />
          Queue Chat
          <Badge className="bg-queue-active text-white ml-2">
            {onlinePatients.filter(p => p.isOnline).length}
          </Badge>
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 w-96 max-w-[calc(100vw-2rem)]">
      <Card className="h-[500px] flex flex-col bg-gradient-card shadow-medical">
        {/* Chat Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-medical-blue text-white rounded-t-lg">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            <div>
              <h3 className="font-semibold">Queue Chat</h3>
              <p className="text-xs opacity-90">General Medicine</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(false)}
            className="h-8 w-8 p-0 hover:bg-white/20 text-white"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Online Patients */}
        <div className="p-3 border-b border-border bg-secondary/30">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">Online Patients</span>
            <Badge variant="outline" className="text-xs">
              {onlinePatients.filter(p => p.isOnline).length}
            </Badge>
          </div>
          <div className="flex gap-2 overflow-x-auto">
            {onlinePatients
              .filter(p => p.isOnline)
              .map((patient) => (
                <div key={patient.id} className="flex flex-col items-center gap-1 min-w-0">
                  <div className="relative">
                    <Avatar className="w-8 h-8 border-2 border-medical-green">
                      <AvatarFallback className="text-xs bg-medical-green/20 text-medical-green">
                        {patient.initials}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-medical-green rounded-full border-2 border-white"></div>
                  </div>
                  <div className="text-center">
                    <p className="text-xs truncate max-w-16">{patient.name.split(' ')[0]}</p>
                    <p className="text-xs text-muted-foreground">#{patient.queuePosition}</p>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.type === 'system' ? 'justify-center' : message.patientId === currentPatient?.id ? 'justify-end' : 'justify-start'}`}>
              {message.type === 'system' ? (
                <div className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
                  {message.message}
                </div>
              ) : (
                <div className={`max-w-[80%] ${message.patientId === currentPatient?.id ? 'bg-medical-blue text-white' : 'bg-secondary'} rounded-lg p-3`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium">
                      {message.patientId === currentPatient?.id ? 'You' : message.patientName}
                    </span>
                    <span className="text-xs opacity-70">
                      {formatTime(message.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm break-words">{message.message}</p>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="p-3 border-t border-border">
          <div className="flex gap-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1"
              maxLength={200}
            />
            <Button
              onClick={sendMessage}
              disabled={!newMessage.trim()}
              size="sm"
              variant="medical"
              className="px-3"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Share experiences about the doctor or ask questions about the process
          </p>
        </div>
      </Card>
    </div>
  );
};

export default LiveChatBox;