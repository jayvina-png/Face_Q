import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Scan, CheckCircle, UserCheck, Loader2 } from "lucide-react";
import faceScanIcon from "@/assets/face-scan-icon.png";
import LiveChatBox from "@/components/LiveChatBox";

const FaceLogin = () => {
  const [scanStatus, setScanStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [patient, setPatient] = useState<any>(null);

  const handleFaceScan = () => {
    setScanStatus('scanning');
    
    // Simulate face scanning process
    setTimeout(() => {
      setScanStatus('success');
      setPatient({
        id: "P001",
        name: "John Doe",
        queueNumber: 28,
        department: "General Medicine",
        estimatedWait: "15 minutes",
        position: 3
      });
    }, 3000);
  };

  const resetScan = () => {
    setScanStatus('idle');
    setPatient(null);
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">Patient Face Login</h2>
            <p className="text-muted-foreground text-lg">
              Look at the camera for secure identification
            </p>
          </div>
          
          <Card className="p-8 bg-gradient-card shadow-soft">
            {scanStatus === 'idle' && (
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-6 bg-secondary rounded-full flex items-center justify-center">
                  <img src={faceScanIcon} alt="Face scan" className="w-16 h-16 opacity-60" />
                </div>
                
                <h3 className="text-xl font-semibold mb-4">Ready to Scan</h3>
                <p className="text-muted-foreground mb-6">
                  Position your face within the frame and click to start scanning
                </p>
                
                <Button 
                  variant="scan" 
                  size="xl" 
                  onClick={handleFaceScan}
                  className="gap-3"
                >
                  <Scan className="w-5 h-5" />
                  Start Face Scan
                </Button>
              </div>
            )}
            
            {scanStatus === 'scanning' && (
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-6 bg-medical-blue/20 rounded-full flex items-center justify-center animate-pulse border-4 border-medical-blue/40">
                  <Loader2 className="w-16 h-16 text-medical-blue animate-spin" />
                </div>
                
                <h3 className="text-xl font-semibold mb-4 text-medical-blue">Scanning Face...</h3>
                <p className="text-muted-foreground mb-6">
                  Please hold still while we identify you
                </p>
                
                <div className="flex justify-center">
                  <div className="flex space-x-1">
                    {[...Array(3)].map((_, i) => (
                      <div
                        key={i}
                        className="w-2 h-2 bg-medical-blue rounded-full animate-bounce"
                        style={{ animationDelay: `${i * 0.2}s` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {scanStatus === 'success' && patient && (
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-6 bg-medical-green/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-16 h-16 text-medical-green" />
                </div>
                
                <h3 className="text-xl font-semibold mb-2 text-medical-green">Welcome Back!</h3>
                <p className="text-lg font-medium mb-6">{patient.name}</p>
                
                <div className="bg-background rounded-lg p-6 mb-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Patient ID:</span>
                    <span className="font-semibold">{patient.id}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Department:</span>
                    <span className="font-semibold">{patient.department}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Queue Number:</span>
                    <span className="font-bold text-xl text-medical-blue">#{patient.queueNumber}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Position in Queue:</span>
                    <span className="font-semibold text-queue-active">{patient.position}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Estimated Wait:</span>
                    <span className="font-semibold text-queue-active">{patient.estimatedWait}</span>
                  </div>
                </div>
                
                <div className="flex gap-4 justify-center">
                  <Button variant="medical" size="lg" className="gap-2">
                    <UserCheck className="w-4 h-4" />
                    View Queue Status
                  </Button>
                  <Button variant="outline" size="lg" onClick={resetScan}>
                    Scan Another Patient
                  </Button>
                </div>
              </div>
            )}
          </Card>
          
          {/* Live Chat - Always show for testing, remove this condition later */}
          <LiveChatBox currentPatient={patient || {
            id: "P001",
            name: "Test Patient", 
            queueNumber: 28,
            department: "General Medicine"
          }} />
        </div>
      </div>
    </section>
  );
};

export default FaceLogin;