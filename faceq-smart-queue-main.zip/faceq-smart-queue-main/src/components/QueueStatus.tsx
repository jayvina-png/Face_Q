import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Users, Activity } from "lucide-react";

const QueueStatus = () => {
  const queueData = [
    {
      department: "General Medicine",
      currentNumber: 15,
      totalWaiting: 8,
      avgWaitTime: "12 min",
      status: "active"
    },
    {
      department: "Cardiology",
      currentNumber: 7,
      totalWaiting: 12,
      avgWaitTime: "25 min",
      status: "busy"
    },
    {
      department: "Pediatrics",
      currentNumber: 23,
      totalWaiting: 5,
      avgWaitTime: "8 min",
      status: "active"
    },
    {
      department: "Emergency",
      currentNumber: 3,
      totalWaiting: 2,
      avgWaitTime: "5 min",
      status: "available"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-queue-active text-white";
      case "busy": return "bg-destructive text-white";
      case "available": return "bg-medical-green text-white";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <section className="py-16 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Live Queue Status</h2>
          <p className="text-muted-foreground text-lg">
            Real-time updates across all departments
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {queueData.map((dept, index) => (
            <Card key={index} className="p-6 hover:shadow-medical transition-all duration-300 bg-gradient-card border-border/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">{dept.department}</h3>
                <Badge className={getStatusColor(dept.status)}>
                  {dept.status}
                </Badge>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-medical-blue" />
                  <span className="text-sm text-muted-foreground">Now Serving:</span>
                  <span className="font-bold text-lg text-medical-blue">#{dept.currentNumber}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Waiting:</span>
                  <span className="font-semibold">{dept.totalWaiting}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Avg Wait:</span>
                  <span className="font-semibold text-queue-active">{dept.avgWaitTime}</span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default QueueStatus;