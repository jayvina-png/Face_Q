import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import QueueStatus from "@/components/QueueStatus";
import FaceLogin from "@/components/FaceLogin";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <QueueStatus />
      <FaceLogin />
    </div>
  );
};

export default Index;
