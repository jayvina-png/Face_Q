import { useState } from "react";
import { ArrowLeft, Users, Clock, UserCheck, AlertCircle, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface QueueItem {
  id: string;
  patientName: string;
  queueNumber: number;
  department: string;
  arrivalTime: string;
  status: "waiting" | "in-progress" | "completed";
  estimatedTime: string;
}

const AdminDashboard = () => {
  const [queues, setQueues] = useState<QueueItem[]>([
    {
      id: "1",
      patientName: "John Smith",
      queueNumber: 1,
      department: "General Medicine",
      arrivalTime: "09:30 AM",
      status: "in-progress",
      estimatedTime: "5 min"
    },
    {
      id: "2", 
      patientName: "Sarah Johnson",
      queueNumber: 2,
      department: "General Medicine",
      arrivalTime: "09:45 AM",
      status: "waiting",
      estimatedTime: "15 min"
    },
    {
      id: "3",
      patientName: "Mike Wilson",
      queueNumber: 3,
      department: "Cardiology",
      arrivalTime: "10:00 AM", 
      status: "waiting",
      estimatedTime: "25 min"
    },
    {
      id: "4",
      patientName: "Emma Davis",
      queueNumber: 4,
      department: "Dermatology",
      arrivalTime: "10:15 AM",
      status: "waiting",
      estimatedTime: "30 min"
    }
  ]);

  const [newPatient, setNewPatient] = useState({
    name: "",
    department: "General Medicine"
  });

  const departments = ["General Medicine", "Cardiology", "Dermatology", "Orthopedics", "Neurology"];

  const addPatient = () => {
    if (!newPatient.name.trim()) return;
    
    const newQueue: QueueItem = {
      id: Date.now().toString(),
      patientName: newPatient.name,
      queueNumber: queues.length + 1,
      department: newPatient.department,
      arrivalTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: "waiting",
      estimatedTime: `${(queues.length + 1) * 10} min`
    };
    
    setQueues([...queues, newQueue]);
    setNewPatient({ name: "", department: "General Medicine" });
  };

  const updateStatus = (id: string, newStatus: QueueItem["status"]) => {
    setQueues(queues.map(queue => 
      queue.id === id ? { ...queue, status: newStatus } : queue
    ));
  };

  const removePatient = (id: string) => {
    setQueues(queues.filter(queue => queue.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "waiting": return "bg-status-waiting";
      case "in-progress": return "bg-status-progress";
      case "completed": return "bg-status-completed";
      default: return "bg-muted";
    }
  };

  const stats = {
    total: queues.length,
    waiting: queues.filter(q => q.status === "waiting").length,
    inProgress: queues.filter(q => q.status === "in-progress").length,
    completed: queues.filter(q => q.status === "completed").length
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-gradient-card shadow-soft">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to Queue
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-medical bg-clip-text text-transparent">
                  Admin Dashboard
                </h1>
                <p className="text-sm text-muted-foreground">Queue Management System</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card border-primary/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="w-4 h-4" />
                Total Patients
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{stats.total}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-orange-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Waiting
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{stats.waiting}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <UserCheck className="w-4 h-4" />
                In Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.inProgress}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Completed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{stats.completed}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Add Patient Form */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Add New Patient
              </CardTitle>
              <CardDescription>
                Add a patient to the queue manually
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="patient-name">Patient Name</Label>
                <Input
                  id="patient-name"
                  value={newPatient.name}
                  onChange={(e) => setNewPatient({ ...newPatient, name: e.target.value })}
                  placeholder="Enter patient name"
                />
              </div>
              <div>
                <Label htmlFor="department">Department</Label>
                <select
                  id="department"
                  className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
                  value={newPatient.department}
                  onChange={(e) => setNewPatient({ ...newPatient, department: e.target.value })}
                >
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
              <Button onClick={addPatient} className="w-full" variant="medical">
                <Plus className="w-4 h-4 mr-2" />
                Add to Queue
              </Button>
            </CardContent>
          </Card>

          {/* Queue Management */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Current Queue</CardTitle>
              <CardDescription>
                Manage patient queue and status updates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {queues.map((queue) => (
                  <div 
                    key={queue.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg bg-card/50 hover:bg-card transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-medical rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">#{queue.queueNumber}</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">{queue.patientName}</h4>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{queue.department}</span>
                          <span>•</span>
                          <span>{queue.arrivalTime}</span>
                          <span>•</span>
                          <span>Est: {queue.estimatedTime}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(queue.status)}>
                        {queue.status.replace("-", " ")}
                      </Badge>
                      
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateStatus(queue.id, "waiting")}
                          disabled={queue.status === "waiting"}
                        >
                          Wait
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateStatus(queue.id, "in-progress")}
                          disabled={queue.status === "in-progress"}
                        >
                          Start
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateStatus(queue.id, "completed")}
                          disabled={queue.status === "completed"}
                        >
                          Done
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => removePatient(queue.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                
                {queues.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No patients in queue
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;